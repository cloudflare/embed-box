console.log("Mama always said life was like a box of chocolates. You never know what you're gonna get. - Forrest Gump")
